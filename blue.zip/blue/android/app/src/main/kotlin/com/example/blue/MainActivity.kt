package com.example.blue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
